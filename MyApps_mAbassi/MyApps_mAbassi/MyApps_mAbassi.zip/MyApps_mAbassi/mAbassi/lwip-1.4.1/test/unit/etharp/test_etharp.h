#ifndef __TEST_ETHARP_H__
#define __TEST_ETHARP_H__

#include "../lwip_check.h"

Suite* etharp_suite(void);

#endif
