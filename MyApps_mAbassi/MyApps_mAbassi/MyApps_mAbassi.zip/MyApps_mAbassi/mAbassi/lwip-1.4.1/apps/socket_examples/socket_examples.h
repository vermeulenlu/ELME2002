#ifndef __SOCKET_EXAMPLES_H__
#define __SOCKET_EXAMPLES_H__

void socket_examples_init(void);

#endif /* __SOCKET_EXAMPLES_H__ */
