I aim to provide a generic SD-Card driver here at some-point in the future.

If you already have one, whereby simple functions providing the data transport can be provided
please get in touch via: http://worm.me.uk/contact/

James