This folder provides a collection of drivers for basic integration of FullFAT with many different devices.

If you can't find the appropriate driver here, when you have written one please submit it to FullFAT for
inclusion in this library.

James@worm.me.uk
