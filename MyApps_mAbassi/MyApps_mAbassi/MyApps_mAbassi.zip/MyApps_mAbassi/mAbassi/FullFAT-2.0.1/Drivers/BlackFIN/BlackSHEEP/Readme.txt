This is a driver for FullFAT that provides instant integration of FullFAT with the BlackSHEEP operating system
from Bluetechnix.

See www.bluetechnix.at for more information about BlackSHEEP.
