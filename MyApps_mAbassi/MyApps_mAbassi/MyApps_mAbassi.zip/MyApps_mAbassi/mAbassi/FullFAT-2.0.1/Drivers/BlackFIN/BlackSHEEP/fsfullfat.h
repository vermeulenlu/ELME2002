#ifndef _FS_FULLFAT_H_
#define _FS_FULLFAT_H_

#include "../../../../../fsmgr.h"

T_FS_FUNCTIONS *fs_fullfat_getFileFunctions(void);

#endif

