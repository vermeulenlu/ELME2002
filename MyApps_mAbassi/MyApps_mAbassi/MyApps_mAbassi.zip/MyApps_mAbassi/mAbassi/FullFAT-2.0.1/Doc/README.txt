Comprehensive documentation is available at:

http://wiki.fullfat-fs.co.uk/

