#ifndef _HOOK_H_
#define _HOOK_H_

#include "cmd_helpers.h"
#include "../../src/fullfat.h"
#include "../../../ffterm/src/ffterm.h"

int hook_commands(FF_ENVIRONMENT *pEnv);

#endif
