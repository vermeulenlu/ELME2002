#ifndef _CMD_TESTSUITE_H_
#define _CMD_TESTSUITE_H_

#include "cmd_helpers.h"
#include "../../src/fullfat.h"
#include "../../../ffterm/src/ffterm.h"

int cmd_testsuite(int argc, char **argv, FF_ENVIRONMENT *pEnv);


#endif
