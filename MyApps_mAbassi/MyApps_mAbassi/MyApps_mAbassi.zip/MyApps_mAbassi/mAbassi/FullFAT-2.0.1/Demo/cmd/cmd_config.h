#ifndef _CMD_CONFIG_H_
#define _CMD_CONFIG_H_

#define FF_CMD_BUFFER_SIZE		(8192*16)
#define FF_CMD_MAX_MOUNTPOINTS	26			// 26 is max for A: .. Z:

#endif
