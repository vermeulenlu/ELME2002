#!/bin/bash

cd Demo/UNIX
./FullFAT